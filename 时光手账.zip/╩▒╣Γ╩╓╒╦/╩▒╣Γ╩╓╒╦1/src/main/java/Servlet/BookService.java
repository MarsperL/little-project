package Servlet;

import JavaBean.Book;

import java.util.List;

public interface BookService {
    List<Book> list();
}//�ӿ�